public class Decision 
{
  String decision;
  public Decision(String d)
  {
    decision = d;
  }

  public void setDecision(String d)
  {
    decision = d;
  }

  public String getDecision(){
    return decision;
  }  
}